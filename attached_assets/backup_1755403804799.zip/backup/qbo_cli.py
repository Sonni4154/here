
#!/usr/bin/env python3
"""
QBO CLI — OAuth + QuickBooks actions (python-quickbooks + intuitlib)

- oauth: start auth, handle callback locally, or exchange code manually
- actions: customer-by-id, customer-by-name, list-products, create-invoice, invoice-pdf

Requires a .env file in the same directory (see README/steps) with:
QBO_CLIENT_ID, QBO_CLIENT_SECRET, QBO_REDIRECT_URI, QBO_ENV, QBO_COMPANY_ID, QBO_REFRESH_TOKEN (optional initially)

Install deps:
    pip install python-quickbooks intuitlib typer fastapi uvicorn python-dotenv requests
"""

import os
import json
import time
import webbrowser
from typing import Optional, List, Tuple, Dict, Any

import typer
import requests
from dotenv import load_dotenv

from intuitlib.client import AuthClient
from intuitlib.enums import Scopes
from quickbooks import QuickBooks
from quickbooks.objects.base import Ref
from quickbooks.objects.customer import Customer
from quickbooks.objects.item import Item
from quickbooks.objects import Invoice, SalesItemLine, SalesItemLineDetail

try:
    from fastapi import FastAPI, Request
    from fastapi.responses import HTMLResponse, JSONResponse
except Exception:
    FastAPI = None  # FastAPI optional

app = typer.Typer(help="QBO CLI — OAuth + common QBO actions")

# ---------- env & utils ----------

def env_required(name: str, default: Optional[str]=None) -> str:
    v = os.getenv(name, default)
    if not v:
        raise RuntimeError(f"Missing required env var: {name}")
    return v

def tokens_file() -> str:
    return os.getenv("QBO_TOKENS_FILE", "qbo_tokens.json")

def base_url(env: str) -> str:
    return "https://sandbox-quickbooks.api.intuit.com" if env.lower().startswith("sand") else "https://quickbooks.api.intuit.com"

def cache_tokens(data: Dict[str, Any]) -> None:
    with open(tokens_file(), "w") as f:
        json.dump(data, f, indent=2)

def load_cached_tokens() -> Dict[str, Any]:
    if os.path.exists(tokens_file()):
        try:
            return json.load(open(tokens_file(), "r"))
        except Exception:
            return {}
    return {}

def ensure_dotenv():
    # load .env next to this script, if present
    here = os.path.dirname(os.path.abspath(__file__))
    env_path = os.path.join(here, ".env")
    load_dotenv(env_path)

# ---------- client wrapper ----------

class QBOCtx:
    def __init__(self) -> None:
        ensure_dotenv()
        self.client_id = env_required("QBO_CLIENT_ID")
        self.client_secret = env_required("QBO_CLIENT_SECRET")
        self.redirect_uri = env_required("QBO_REDIRECT_URI")
        self.env = os.getenv("QBO_ENV", "sandbox")
        self.company_id = env_required("QBO_COMPANY_ID")
        minor_env = os.getenv("QBO_MINOR_VERSION", "").strip()
        from quickbooks import QuickBooks as _QB
        min_supported = getattr(_QB, "MINIMUM_MINOR_VERSION", 1)
        self.minor = int(minor_env) if minor_env.isdigit() else min_supported
        if self.minor < min_supported:
            self.minor = min_supported
        self.refresh_token = os.getenv("QBO_REFRESH_TOKEN", "")
        cached = load_cached_tokens()
        self.access_token = cached.get("access_token")
        self.expires_at = float(cached.get("expires_at", 0))

        self.auth_client = AuthClient(
            client_id=self.client_id,
            client_secret=self.client_secret,
            environment="sandbox" if self.env.lower().startswith("sand") else "production",
            redirect_uri=self.redirect_uri,
        )
        # QuickBooks SDK instance — will refresh access token on demand
        self.qb = QuickBooks(
            auth_client=self.auth_client,
            refresh_token=self.refresh_token if self.refresh_token else None,
            company_id=self.company_id,
            minorversion=self.minor,
        )

    def _cache_after_token(self, tokens: Dict[str, Any]):
        if not tokens or "access_token" not in tokens:
            raise RuntimeError("Token exchange/refresh returned no tokens. Likely causes: invalid/expired refresh token, wrong Intuit app creds, missing offline_access, or environment/realm mismatch.")
        self.access_token = tokens.get("access_token")
        self.auth_client.access_token = self.access_token
        # rotate refresh if provided
        if tokens.get("refresh_token"):
            self.refresh_token = tokens["refresh_token"]
            os.environ["QBO_REFRESH_TOKEN"] = self.refresh_token

        cache_tokens({
            "access_token": self.access_token,
            "refresh_token": self.refresh_token,
            "expires_at": time.time() + int(tokens.get("expires_in", 3600)) - 60,
        })

    def ensure_access_token(self):
        if self.access_token and time.time() < self.expires_at:
            self.auth_client.access_token = self.access_token
            return
        if not self.refresh_token:
            raise RuntimeError("No refresh token set yet. Run: qbo-cli oauth-start (and callback) or oauth-exchange.")
        try:
            tokens = self.auth_client.refresh(self.refresh_token)
        except Exception as e:
            raise RuntimeError(f"Refresh failed: {e}. Check CLIENT_ID/SECRET, QBO_ENV (sandbox vs production), and QBO_REFRESH_TOKEN validity.")
        self._cache_after_token(tokens)

    # REST headers for endpoints not in the SDK (e.g., PDF)
    def headers(self, accept="application/json"):
        self.ensure_access_token()
        return {"Authorization": f"Bearer {self.access_token}", "Accept": accept, "Content-Type": "application/json"}

    @property
    def api_base(self) -> str:
        return base_url(self.env)

# ---------- OAuth commands ----------

@app.command("oauth-start")
def oauth_start(open_browser: bool=True, scopes: List[str]=typer.Option(
    ["com.intuit.quickbooks.accounting", "openid", "profile", "email", "phone", "address", "com.intuit.quickbooks.payment", "offline_access"],
    help="OAuth scopes"),
):
    """
    Begin OAuth flow: prints auth URL (and opens browser if possible).
    Use together with 'oauth-serve' to handle the callback locally,
    or use 'oauth-exchange' to paste back the ?code and ?realmId values.
    """
    ctx = QBOCtx()
    scope_objs = []
    for s in scopes:
        try:
            scope_objs.append(Scopes[s.replace('.', '_')])  # allow dotted names
        except KeyError:
            # fallback to direct string (intuitlib also accepts raw strings)
            scope_objs.append(s)
    url = ctx.auth_client.get_authorization_url(scope_objs)
    typer.echo("Authorize this app by visiting:\n" + url)
    if open_browser:
        try:
            webbrowser.open(url)
        except Exception:
            pass

@app.command("oauth-serve")
def oauth_serve(host: str="127.0.0.1", port: int=8010, write_env: bool=False):
    """
    Start a tiny FastAPI server to receive the redirect at /callback.
    Ensure your Intuit app lists http://127.0.0.1:8010/callback among Redirect URIs.
    """
    if FastAPI is None:
        raise typer.BadParameter("FastAPI not installed. pip install fastapi uvicorn")

    ctx = QBOCtx()
    api = FastAPI()

    @api.get("/")
    def root():
        return HTMLResponse("<h3>QBO CLI OAuth helper</h3><p>Waiting for /callback ...</p>")

    @api.get("/callback")
    def callback(request: Request):
        code = request.query_params.get("code")
        realm_id = request.query_params.get("realmId")
        if not code or not realm_id:
            return HTMLResponse("<p>Missing code or realmId</p>", status_code=400)
        tokens = ctx.auth_client.get_bearer_token(code, realm_id)
        ctx._cache_after_token(tokens)
        if write_env:
            # best effort append/replace QBO_REFRESH_TOKEN in .env
            here = os.path.dirname(os.path.abspath(__file__))
            env_path = os.path.join(here, ".env")
            try:
                lines = []
                if os.path.exists(env_path):
                    lines = open(env_path, "r").read().splitlines()
                key = "QBO_REFRESH_TOKEN="
                found = False
                for i, line in enumerate(lines):
                    if line.startswith(key):
                        lines[i] = key + ctx.refresh_token
                        found = True
                        break
                if not found:
                    lines.append(key + ctx.refresh_token)
                with open(env_path, "w") as f:
                    f.write("\n".join(lines) + "\n")
            except Exception:
                pass
        return HTMLResponse("<h3>Tokens received.</h3><p>You can close this window.</p>")

    import uvicorn
    uvicorn.run(api, host=host, port=port)

@app.command("oauth-exchange")
def oauth_exchange(code: str, realm_id: str, write_env: bool=False):
    """Manually exchange ?code and ?realmId for tokens and cache them."""
    ctx = QBOCtx()
    tokens = ctx.auth_client.get_bearer_token(code, realm_id)
    ctx._cache_after_token(tokens)
    if write_env and ctx.refresh_token:
        here = os.path.dirname(os.path.abspath(__file__))
        env_path = os.path.join(here, ".env")
        # update .env with refresh token
        try:
            lines = []
            if os.path.exists(env_path):
                lines = open(env_path, "r").read().splitlines()
            key = "QBO_REFRESH_TOKEN="
            found = False
            for i, line in enumerate(lines):
                if line.startswith(key):
                    lines[i] = key + ctx.refresh_token
                    found = True
                    break
            if not found:
                lines.append(key + ctx.refresh_token)
            with open(env_path, "w") as f:
                f.write("\n".join(lines) + "\n")
        except Exception:
            pass
    typer.echo("Tokens saved to " + tokens_file())

# ---------- Action commands ----------

@app.command("customer-by-id")
def customer_by_id(customer_id: str):
    ctx = QBOCtx()
    ctx.ensure_access_token()
    cust = Customer.get(customer_id, qb=ctx.qb)
    typer.echo(json.dumps(cust.to_v3_dict(), indent=2))


@app.command("customer-by-name")
def customer_by_name(name: str):
    ctx = QBOCtx()
    ctx.ensure_access_token()
    # Avoid backslashes inside f-string expressions (Python restriction):
    safe_name = name.replace("'", "''")
    q = f"select * from Customer where DisplayName like '%{safe_name}%'"
    res = ctx.qb.query(q) or []
    typer.echo(json.dumps([c.to_v3_dict() for c in res], indent=2))

@app.command("list-products")
def list_products(active_only: bool=True, limit: int=50):
    ctx = QBOCtx()
    ctx.ensure_access_token()
    where = "where Active = true" if active_only else ""
    q = f"select Id, Name, Type, Active, IncomeAccountRef from Item {where} startposition 1 maxresults {int(limit)}"
    res = ctx.qb.query(q) or []
    typer.echo(json.dumps([i.to_v3_dict() for i in res], indent=2))

@app.command("create-invoice")
def create_invoice(customer_id: str, item: List[str]=typer.Option(..., help="ITEM_ID:QTY:UNIT_PRICE")):
    ctx = QBOCtx()
    ctx.ensure_access_token()

    lines: List[SalesItemLine] = []
    for spec in item:
        try:
            item_id, qty, unit_price = spec.split(":")
            qty = float(qty); unit_price = float(unit_price)
        except Exception:
            raise typer.BadParameter(f"Bad item spec: {spec}. Expected ITEM_ID:QTY:UNIT_PRICE")

        line = SalesItemLine()
        line.Amount = qty * unit_price
        line.DetailType = "SalesItemLineDetail"
        det = SalesItemLineDetail()
        det.Qty = qty
        det.UnitPrice = unit_price
        det.ItemRef = Ref()
        det.ItemRef.value = str(item_id)
        line.SalesItemLineDetail = det
        lines.append(line)

    inv = Invoice()
    inv.CustomerRef = Ref()
    inv.CustomerRef.value = str(customer_id)
    inv.Line = lines
    inv.save(qb=ctx.qb)
    typer.echo(json.dumps(inv.to_v3_dict(), indent=2))

@app.command("invoice-pdf")
def invoice_pdf(invoice_id: str, out: str="invoice.pdf"):
    ctx = QBOCtx()
    ctx.ensure_access_token()
    url = f"{ctx.api_base}/v3/company/{ctx.company_id}/invoice/{invoice_id}/pdf"
    if ctx.minor:
        url += f"?minorversion={ctx.minor}"
    r = requests.get(url, headers=ctx.headers(accept="application/pdf"), stream=True)
    if r.status_code >= 400:
        try:
            payload = r.json()
        except Exception:
            payload = r.text
        raise RuntimeError(f"Failed to fetch PDF ({r.status_code}): {payload}")
    with open(out, "wb") as f:
        for chunk in r.iter_content(65536):
            if chunk:
                f.write(chunk)
    typer.echo(f"Wrote {out}")

def main():
    app()

if __name__ == "__main__":
    main()
