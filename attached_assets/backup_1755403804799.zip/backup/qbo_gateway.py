# /opt/qbo-cli/qbo_gateway.py



import os, json, time, secrets, hashlib, base64

from typing import Dict, Any

import requests



from fastapi import FastAPI, Request, HTTPException

from fastapi.responses import HTMLResponse, RedirectResponse, JSONResponse



# ===== Config =====

AUTH_URL  = "https://appcenter.intuit.com/connect/oauth2"

TOKEN_URL = "https://oauth.platform.intuit.com/oauth2/v1/tokens/bearer"

REVOKE_URL= "https://developer.api.intuit.com/v2/oauth2/tokens/revoke"



SCOPE = "com.intuit.quickbooks.accounting"   # Accounting API scope only



app = FastAPI()

STATE: Dict[str, Dict[str, Any]] = {}



def _state_path():

    import os

    return os.getenv("QBO_PKCE_STATE_FILE", "/opt/qbo-cli/pkce_state.json")



def _load_state():

    try:

        import json, os

        with open(_state_path()) as f:

            return json.load(f)

    except Exception:

        return {}



def _save_state(d):

    import json, os

    p = _state_path()

    tmp = p + ".tmp"

    with open(tmp, "w") as f:

        json.dump(d, f)

    os.replace(tmp, p)

    try:

        import pwd, grp

        os.chown(p, pwd.getpwnam("www-data").pw_uid, grp.getgrnam("www-data").gr_gid)

        os.chmod(p, 0o640)

    except Exception:

        pass



def _state_put(key, val):

    d = _load_state()

    d[key] = val

    _save_state(d)



def _state_pop(key):

    d = _load_state()

    val = d.pop(key, None)

    _save_state(d)

    return val

        # state -> {"ts":..., "verifier":...}



def tokens_path() -> str:

    return os.getenv("QBO_TOKENS_FILE", "/opt/qbo-cli/qbo_tokens.json")



def save_tokens(tokens: Dict[str, Any]):

    p = tokens_path()

    tmp = p + ".tmp"

    with open(tmp, "w") as f:

        json.dump(tokens, f, indent=2)

    os.replace(tmp, p)

    # relax perms for your CLI user (group-readable)

    try:

        import grp, pwd, stat

        os.chown(p, pwd.getpwnam("www-data").pw_uid, grp.getgrnam("www-data").gr_gid)

        os.chmod(p, 0o640)

    except Exception:

        pass



def load_tokens() -> Dict[str, Any]:

    try:

        with open(tokens_path()) as f:

            return json.load(f)

    except Exception:

        return {}



def _mask(s: str) -> str:

    if not s: return ""

    return s[:6] + "…" + s[-4:] if len(s) > 12 else "***"



# ===== Debug & health =====

@app.get("/quickbooks/health")

def health():

    exists = os.path.exists(tokens_path())

    t = load_tokens() if exists else {}

    return {

        "ok": True,

        "exists": exists,

        "has_access": bool(t.get("access_token")),

        "has_refresh": bool(t.get("refresh_token")),
        "pkce_file": _state_path(),

        "tokens_file": tokens_path(),

    }



@app.get("/quickbooks/debug")

def debug():

    return {

        "QBO_ENV": os.getenv("QBO_ENV"),

        "QBO_REDIRECT_URI": os.getenv("QBO_REDIRECT_URI"),

        "QBO_CLIENT_ID": _mask(os.getenv("QBO_CLIENT_ID")),

        "QBO_CLIENT_SECRET": _mask(os.getenv("QBO_CLIENT_SECRET")),

        "QBO_TOKENS_FILE": tokens_path(),

    }



@app.get("/quickbooks/auth-url")

def auth_url_preview():

    # Build the raw authorize URL (without state/PKCE) for inspection

    from urllib.parse import urlencode

    params = {

        "client_id": os.environ["QBO_CLIENT_ID"],

        "response_type": "code",

        "scope": SCOPE,

        "redirect_uri": os.environ["QBO_REDIRECT_URI"],

    }

    url = AUTH_URL + "?" + urlencode(params)

    return {"url": url, "client_id": params["client_id"], "redirect_uri": params["redirect_uri"], "scope": params["scope"]}



# ===== OAuth: connect -> callback (PKCE, supports GET & POST) =====

@app.get("/quickbooks/connect")

def connect():

    from urllib.parse import urlencode

    # CSRF state

    state = secrets.token_urlsafe(24)

    # PKCE verifier/challenge

    verifier = secrets.token_urlsafe(64)[:128]

    challenge = base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest()).decode().rstrip("=")

    # store for callback

    STATE[state] = {"ts": time.time()}; _state_put(state, {"ts": time.time(), "verifier": verifier})

    params = {

        "client_id": os.environ["QBO_CLIENT_ID"],

        "response_type": "code",

        "scope": SCOPE,

        "redirect_uri": os.environ["QBO_REDIRECT_URI"],

        "state": state,

        "code_challenge": challenge,

        "code_challenge_method": "S256",

    }

    return RedirectResponse(AUTH_URL + "?" + urlencode(params))



@app.api_route("/quickbooks/callback", methods=["GET", "POST"])

async def callback(request: Request):

    # Accept GET with query params, or POST (form_post)

    params = dict(request.query_params)

    if request.method == "POST":

        try:

            form = await request.form()

            for k, v in form.items():

                if k not in params:

                    params[k] = v

        except Exception:

            pass



    # If IdP returned an error, surface it directly

    if "error" in params:

        return HTMLResponse(f"<h3>Intuit error</h3><pre>{params}</pre>", status_code=400)



    code = params.get("code")

    state = params.get("state")

    if not code:

        return HTMLResponse(f"<h3>Missing code</h3>", status_code=400)



    # Optional state check (guard against restarts during testing)

    if os.getenv("QBO_SKIP_STATE") not in ("1","true","True","yes","Yes"):

        info = _state_pop(state) or STATE.pop(state, None)

        if not info:

            return HTMLResponse("<h3>Invalid/missing state</h3>", status_code=400)

        verifier = info.get("verifier")

    else:

        info = STATE.pop(state, None) or {}

        verifier = info.get("verifier")



    # Exchange code for tokens (client_secret_basic; include PKCE verifier)

    cid   = os.environ["QBO_CLIENT_ID"]

    cs    = os.environ["QBO_CLIENT_SECRET"]

    redir = os.environ["QBO_REDIRECT_URI"]

    auth  = base64.b64encode((cid + ":" + cs).encode()).decode()



    data = {

        "grant_type": "authorization_code",

        "code": code,

        "redirect_uri": redir,

    }

    if verifier:

        data["code_verifier"] = verifier



    resp = requests.post(

        TOKEN_URL,

        headers={"Authorization": "Basic " + auth, "Accept": "application/json"},

        data=data,

        timeout=30,

    )

    if resp.status_code != 200:

        return HTMLResponse(f"<h3>Token exchange failed</h3><p>HTTP {resp.status_code}</p><pre>{resp.text}</pre>", status_code=400)



    tokens = resp.json()

    if "access_token" not in tokens:

        return HTMLResponse("<h3>No tokens returned</h3>", status_code=400)



    save_tokens(tokens)

    return HTMLResponse("<h3>QuickBooks connected ✅</h3>")



# ===== Disconnect (revoke) =====

@app.get("/quickbooks/disconnect")

def disconnect():

    t = load_tokens()

    rt = t.get("refresh_token") or t.get("access_token")

    if not rt:

        return HTMLResponse("<h3>No tokens to revoke.</h3>")

    cid = os.environ["QBO_CLIENT_ID"]

    cs  = os.environ["QBO_CLIENT_SECRET"]

    auth = base64.b64encode((cid+":"+cs).encode()).decode()

    r = requests.post(

        REVOKE_URL,

        headers={"Authorization": "Basic "+auth, "Accept":"application/json"},

        data={"token": rt},

        timeout=30

    )

    try:

        os.remove(tokens_path())

    except Exception:

        pass

    if r.status_code in (200, 204):

        return HTMLResponse("<h3>Disconnected.</h3>")

    return HTMLResponse(f"<h3>Revoke failed</h3><pre>{r.status_code} {r.text}</pre>", status_code=400)



# ===== Minimal webhook (optional) =====

@app.post("/quickbooks/webhook")

async def webhook(request: Request):

    body = await request.body()

    # You can verify X-Intuit-Signature here if you set a verifier in your app

    with open("/opt/qbo-cli/last_webhook.json", "wb") as f:

        f.write(body)

    return JSONResponse({"ok": True})

